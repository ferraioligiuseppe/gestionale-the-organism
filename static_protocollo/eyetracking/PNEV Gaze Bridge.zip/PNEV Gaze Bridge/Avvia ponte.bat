@echo off
title PNEV Gaze Bridge
cd /d "%~dp0"
rem Serve Python 3 a 32 bit (la libreria del Tobii EyeX e' a 32 bit)
py -3-32 pnev_gaze_bridge.py %*
if errorlevel 9009 (
  echo.
  echo   Python a 32 bit non trovato.
  echo   Installalo da python.org: Downloads - Windows - "Windows installer (32-bit)".
  pause
)
