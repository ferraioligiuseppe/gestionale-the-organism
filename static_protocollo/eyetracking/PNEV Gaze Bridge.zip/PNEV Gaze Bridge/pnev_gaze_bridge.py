# -*- coding: utf-8 -*-
"""
PNEV Gaze Bridge — ponte tra il Tobii EyeX e le pagine web dello Studio The Organism.

Legge lo sguardo dal motore Tobii EyeX (Tobii.EyeX.Client.dll, 32 bit) e lo trasmette
in tempo reale alle pagine del browser sullo stesso PC, su ws://127.0.0.1:8765.

Uso:  doppio clic su «Avvia ponte.bat»  (serve Python 3 a 32 bit)
      --prova   → dati simulati, senza barra (per controllare che tutto funzioni)

Ogni messaggio inviato è JSON:
  {"tipo":"sguardo","t":<ms>,"x":<px>,"y":<px>,"nx":<0-1>,"ny":<0-1>,"valido":true}
  {"tipo":"stato","connesso":true|false,"fonte":"eyex"|"prova","schermo":[larghezza,altezza]}
Solo indirizzo locale (127.0.0.1): dall'esterno del PC non è raggiungibile.
"""
import asyncio, base64, ctypes, hashlib, json, math, os, struct, sys, threading, time

PORTA = 8765
VERSIONE = "1.3"

# ─────────────────────────── server WebSocket minimo (solo libreria standard) ───────────────────────────
class ServerWS:
    def __init__(self):
        self.su_comando = None          # funzione chiamata con i comandi delle pagine
        self.client = set()
        self.loop = None
        self.ultimo_stato = {"tipo": "stato", "connesso": False, "fonte": "", "schermo": [0, 0]}

    async def gestisci(self, reader, writer):
        try:
            richiesta = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), timeout=10)
        except Exception:
            writer.close(); return
        righe = richiesta.decode("latin-1").split("\r\n")
        intest = {}
        for r in righe[1:]:
            if ":" in r:
                k, v = r.split(":", 1); intest[k.strip().lower()] = v.strip()
        chiave = intest.get("sec-websocket-key")
        if not chiave:  # richiesta HTTP normale: piccola pagina di stato
            corpo = json.dumps({"ponte": "PNEV Gaze Bridge", "versione": VERSIONE, **self.ultimo_stato}).encode()
            writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nAccess-Control-Allow-Origin: *\r\n"
                         b"Content-Length: " + str(len(corpo)).encode() + b"\r\nConnection: close\r\n\r\n" + corpo)
            await writer.drain(); writer.close(); return
        accetta = base64.b64encode(hashlib.sha1((chiave + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
        writer.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                      f"Sec-WebSocket-Accept: {accetta}\r\n\r\n").encode())
        await writer.drain()
        self.client.add(writer)
        self._invia_a(writer, self.ultimo_stato)
        try:
            while True:  # leggo i messaggi in arrivo solo per accorgermi della chiusura
                h = await reader.readexactly(2)
                op = h[0] & 0x0F; lung = h[1] & 0x7F; mask = h[1] & 0x80
                if lung == 126: lung = struct.unpack(">H", await reader.readexactly(2))[0]
                elif lung == 127: lung = struct.unpack(">Q", await reader.readexactly(8))[0]
                chiave_m = await reader.readexactly(4) if mask else b"\0\0\0\0"
                dati = await reader.readexactly(lung) if lung else b""
                if op == 0x8: break
                if op == 0x1 and dati:
                    testo = bytes(b ^ chiave_m[i % 4] for i, b in enumerate(dati)).decode("utf-8", "replace")
                    try:
                        msg = json.loads(testo)
                    except Exception:
                        continue
                    if self.su_comando and isinstance(msg, dict) and msg.get("comando"):
                        risposta = self.su_comando(msg)
                        if risposta: self._invia_a(writer, risposta)
        except Exception:
            pass
        finally:
            self.client.discard(writer)
            try: writer.close()
            except Exception: pass

    @staticmethod
    def _cornice(testo: str) -> bytes:
        dati = testo.encode("utf-8"); n = len(dati)
        if n < 126: return bytes([0x81, n]) + dati
        if n < 65536: return bytes([0x81, 126]) + struct.pack(">H", n) + dati
        return bytes([0x81, 127]) + struct.pack(">Q", n) + dati

    def _invia_a(self, w, msg):
        try: w.write(self._cornice(json.dumps(msg)))
        except Exception: self.client.discard(w)

    def pubblica(self, msg):
        """Chiamabile da qualsiasi thread (anche dal callback del Tobii)."""
        if msg.get("tipo") == "stato": self.ultimo_stato = msg
        if self.loop and self.client:
            self.loop.call_soon_threadsafe(lambda: [self._invia_a(w, msg) for w in list(self.client)])

    async def avvia(self):
        self.loop = asyncio.get_running_loop()
        srv = await asyncio.start_server(self.gestisci, "127.0.0.1", PORTA)
        print(f"  Ponte in ascolto su ws://127.0.0.1:{PORTA}  (lascia aperta questa finestra)")
        async with srv: await srv.serve_forever()


def dimensioni_schermo():
    try:
        u = ctypes.windll.user32
        try: u.SetProcessDPIAware()
        except Exception: pass
        return [u.GetSystemMetrics(0), u.GetSystemMetrics(1)]
    except Exception:
        return [1920, 1080]


# ─────────────────────────── Tobii EyeX (API C di Tobii.EyeX.Client.dll) ───────────────────────────
# Nella libreria EyeX gli elenchi partono da 1: TX_RESULT_UNKNOWN = 1, TX_RESULT_OK = 2
TX_RESULT_OK = 2
TX_CONNECTIONSTATE_CONNECTED = 1
STATI_CONNESSIONE = {1: "collegato", 2: "scollegato", 3: "in collegamento…", 4: "motore Tobii troppo vecchio", 5: "motore Tobii troppo nuovo"}
TX_GAZEPOINTDATAMODE_LIGHTLYFILTERED = 2

class TX_GAZEPOINTDATAPARAMS(ctypes.Structure):
    _fields_ = [("GazePointDataMode", ctypes.c_int)]

class TX_GAZEPOINTDATAEVENTPARAMS(ctypes.Structure):
    _fields_ = [("GazePointDataMode", ctypes.c_int), ("Timestamp", ctypes.c_double),
                ("X", ctypes.c_double), ("Y", ctypes.c_double)]

def trova_dll():
    qui = os.path.dirname(os.path.abspath(__file__))
    candidati = [os.path.join(qui, "Tobii.EyeX.Client.dll"),
                 r"C:\TSS Clinical Eye Tracker 5L\Tobii.EyeX.Client.dll",
                 r"C:\Program Files (x86)\Tobii\Tobii EyeX\Tobii.EyeX.Client.dll",
                 r"C:\Program Files\Tobii\Tobii EyeX\Tobii.EyeX.Client.dll"]
    for c in candidati:
        if os.path.exists(c): return c
    return None


class SorgenteEyeX:
    def __init__(self, server: ServerWS):
        self.server = server
        self.schermo = dimensioni_schermo()
        self.tipo_comportamento = None   # scoperto al primo evento
        self.campioni = 0

    def avvia(self):
        if struct.calcsize("P") != 4:
            raise RuntimeError("Serve Python a 32 bit: la libreria del Tobii EyeX è a 32 bit. "
                               "Installa «Windows installer (32-bit)» da python.org.")
        percorso = trova_dll()
        if not percorso:
            raise RuntimeError("Non trovo Tobii.EyeX.Client.dll. Copiala nella cartella del ponte "
                               "(la trovi in C:\\TSS Clinical Eye Tracker 5L).")
        os.add_dll_directory(os.path.dirname(percorso)) if hasattr(os, "add_dll_directory") else None
        print(f"  Libreria Tobii: {percorso}")
        tx = ctypes.CDLL(percorso)
        self.tx = tx
        H = ctypes.c_void_p
        CB_DATI = ctypes.CFUNCTYPE(None, H, ctypes.c_void_p)
        CB_CONN = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
        self._cb_evento = CB_DATI(self._su_evento)          # tengo i riferimenti: se no Python li libera
        self._cb_conn = CB_CONN(self._su_connessione)
        self._cb_commit = CB_DATI(self._su_commit)

        r = tx.txInitializeEyeX(0, None, None, None, None)
        if r != TX_RESULT_OK: raise RuntimeError(f"txInitializeEyeX ha risposto {r}")
        self.ctx = H()
        r = tx.txCreateContext(ctypes.byref(self.ctx), 0)
        if r != TX_RESULT_OK: raise RuntimeError(f"txCreateContext ha risposto {r}")

        self.snapshot = H(); interattore = H()
        r = tx.txCreateGlobalInteractorSnapshot(self.ctx, b"PNEV_sguardo", ctypes.byref(self.snapshot), ctypes.byref(interattore))
        if r != TX_RESULT_OK: raise RuntimeError(f"txCreateGlobalInteractorSnapshot ha risposto {r}")
        par = TX_GAZEPOINTDATAPARAMS(TX_GAZEPOINTDATAMODE_LIGHTLYFILTERED)
        r = tx.txCreateGazePointDataBehavior(interattore, ctypes.byref(par))
        if r != TX_RESULT_OK: raise RuntimeError(f"txCreateGazePointDataBehavior ha risposto {r}")
        tx.txReleaseObject(ctypes.byref(interattore))

        t1 = ctypes.c_int(); t2 = ctypes.c_int()
        tx.txRegisterConnectionStateChangedHandler(self.ctx, ctypes.byref(t1), self._cb_conn, None)
        tx.txRegisterEventHandler(self.ctx, ctypes.byref(t2), self._cb_evento, None)
        r = tx.txEnableConnection(self.ctx)
        if r != TX_RESULT_OK: raise RuntimeError(f"txEnableConnection ha risposto {r}")
        print("  In attesa del motore Tobii EyeX…")

    # callback chiamati dal Tobii (su un suo thread)
    def _su_connessione(self, stato, _):
        connesso = stato == TX_CONNECTIONSTATE_CONNECTED
        print("  Tobii EyeX: " + ("COLLEGATO ✓" if connesso else f"{STATI_CONNESSIONE.get(stato, 'stato')} ({stato})"))
        if connesso:
            self.tx.txCommitSnapshotAsync(self.snapshot, self._cb_commit, None)
        self.server.pubblica({"tipo": "stato", "connesso": connesso, "fonte": "eyex", "schermo": self.schermo})

    def _su_commit(self, h_async, _):
        pass

    # TX_CONFIGURATIONTOOL: 1 impostazioni EyeX, 2 ricalibra, 3 calibrazione ospite, 4 nuovo profilo, 5 prova
    STRUMENTI = {"calibra_tobii": 2, "calibrazione_ospite": 3, "nuovo_profilo": 4, "impostazioni_tobii": 1, "prova_tobii": 5}

    def comando(self, msg):
        c = msg.get("comando")
        if c in self.STRUMENTI:
            r = self.tx.txLaunchConfigurationTool(self.ctx, self.STRUMENTI[c], self._cb_commit, None)
            ok = r == TX_RESULT_OK
            print(f"  Comando dalla pagina: {c} → " + ("aperto" if ok else f"non riuscito ({r})"))
            return {"tipo": "risposta", "comando": c, "ok": ok, "codice": r}
        return {"tipo": "risposta", "comando": c, "ok": False, "errore": "comando sconosciuto"}

    def _su_evento(self, h_async, _):
        tx = self.tx; H = ctypes.c_void_p
        evento = H()
        if tx.txGetAsyncDataContent(h_async, ctypes.byref(evento)) != TX_RESULT_OK: return
        try:
            tipi = [self.tipo_comportamento] if self.tipo_comportamento else range(1, 9)
            for tipo in tipi:
                comp = H()
                if tx.txGetEventBehavior(evento, ctypes.byref(comp), tipo) != TX_RESULT_OK: continue
                p = TX_GAZEPOINTDATAEVENTPARAMS()
                ok = tx.txGetGazePointDataEventParams(comp, ctypes.byref(p)) == TX_RESULT_OK
                tx.txReleaseObject(ctypes.byref(comp))
                if ok:
                    self.tipo_comportamento = tipo
                    self._pubblica(p.Timestamp, p.X, p.Y)
                    break
        finally:
            tx.txReleaseObject(ctypes.byref(evento))

    def _pubblica(self, t, x, y):
        w, h = self.schermo
        valido = not (math.isnan(x) or math.isnan(y))
        self.campioni += 1
        self.server.pubblica({"tipo": "sguardo", "t": round(t, 2), "x": round(x, 1), "y": round(y, 1),
                              "nx": round(x / w, 5) if valido else None, "ny": round(y / h, 5) if valido else None,
                              "valido": valido})


class SorgenteProva:
    """Dati simulati: lo sguardo fa un percorso a otto con piccole fissazioni e saccadi."""
    def __init__(self, server: ServerWS):
        self.server = server; self.schermo = dimensioni_schermo(); self.campioni = 0

    def comando(self, msg):
        print(f"  Comando dalla pagina: {msg.get('comando')} (in prova non apre nulla)")
        return {"tipo": "risposta", "comando": msg.get("comando"), "ok": True, "prova": True}

    def avvia(self):
        self.server.pubblica({"tipo": "stato", "connesso": True, "fonte": "prova", "schermo": self.schermo})
        threading.Thread(target=self._giro, daemon=True).start()
        print("  MODALITÀ PROVA: dati simulati (nessuna barra)")

    def _giro(self):
        w, h = self.schermo; t0 = time.time()
        while True:
            t = time.time() - t0
            fase = math.floor(t * 3) / 3          # a scatti: simula fissazioni + saccadi
            x = w / 2 + w * 0.3 * math.sin(fase * 0.9); y = h / 2 + h * 0.25 * math.sin(fase * 1.8)
            x += (hash(int(t * 60)) % 7 - 3); y += (hash(int(t * 61)) % 7 - 3)
            self.campioni += 1
            self.server.pubblica({"tipo": "sguardo", "t": round(t * 1000, 2), "x": round(x, 1), "y": round(y, 1),
                                  "nx": round(x / w, 5), "ny": round(y / h, 5), "valido": True})
            time.sleep(1 / 60)


async def principale(prova: bool):
    print(f"\n  PNEV Gaze Bridge {VERSIONE} — Studio The Organism\n  " + "─" * 46)
    server = ServerWS()
    sorgente = SorgenteProva(server) if prova else SorgenteEyeX(server)
    server.su_comando = sorgente.comando

    async def contatore():
        prima = 0
        while True:
            await asyncio.sleep(5)
            n = sorgente.campioni - prima; prima = sorgente.campioni
            print(f"  {n/5:5.1f} campioni/s · pagine collegate: {len(server.client)}")

    srv = await asyncio.start_server(server.gestisci, "127.0.0.1", PORTA)   # se la porta è occupata si ferma qui
    server.loop = asyncio.get_running_loop()
    print(f"  Ponte in ascolto su ws://127.0.0.1:{PORTA}  (lascia aperta questa finestra)")
    sorgente.avvia()
    async with srv:
        await asyncio.gather(srv.serve_forever(), contatore())


if __name__ == "__main__":
    try:
        asyncio.run(principale("--prova" in sys.argv))
    except KeyboardInterrupt:
        pass
    except OSError as e:
        if getattr(e, "winerror", None) == 10048 or e.errno in (98, 10048):
            print("\n  Il ponte è GIÀ ACCESO in un'altra finestra (porta 8765 occupata).")
            print("  Chiudi le altre finestre nere del ponte, poi avvia di nuovo solo «Avvia ponte.bat».")
        else:
            print("\n  ERRORE:", e)
        input("\n  Premi Invio per chiudere")
    except Exception as e:
        print("\n  ERRORE:", e)
        input("\n  Premi Invio per chiudere")
