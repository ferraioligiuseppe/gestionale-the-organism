@echo off
title PNEV Gaze Bridge - PROVA
cd /d "%~dp0"
py -3-32 pnev_gaze_bridge.py --prova
if errorlevel 9009 py pnev_gaze_bridge.py --prova
pause
